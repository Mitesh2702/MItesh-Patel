export const RouteConstats = {
    ABOUT_US:"/aboutus",
    CONTACT_US:"/contactus",
    PRODUCTS: "/products",
    PRODUCT_DETAILS: "/products/product/:id",

};
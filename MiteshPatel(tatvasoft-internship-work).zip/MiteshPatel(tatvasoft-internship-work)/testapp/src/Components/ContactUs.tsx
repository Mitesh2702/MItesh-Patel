import React, { Fragment } from 'react'

const ContactUs : React.FC = ()=>{
    return (
        <Fragment>
            <h2>Contact Us Page.</h2>
        </Fragment>
      )
}
export default ContactUs
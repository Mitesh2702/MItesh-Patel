import React from "react";
 
const PageNotFound : React.FC = () =>{
    return(
        <h2>Page Not Found.</h2>
    );
}

export default PageNotFound;
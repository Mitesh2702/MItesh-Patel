import React, { Fragment } from "react";

const Home : React.FC = ()=>{
    return (
        <Fragment>
            <h1>Welcome to Home.</h1>
        </Fragment>
    );
};

export default Home;
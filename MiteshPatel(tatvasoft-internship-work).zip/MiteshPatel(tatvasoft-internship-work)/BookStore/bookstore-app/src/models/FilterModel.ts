export default class FilterModel {
  pageIndex!: number;
  pageSize?: number;
  keyword?: string;
}